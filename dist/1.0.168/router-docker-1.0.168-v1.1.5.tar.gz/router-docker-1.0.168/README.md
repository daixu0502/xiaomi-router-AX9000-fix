# 1.0.168 Docker 与原厂页面恢复

适用于 **AX9000 / RA70 国行原厂稳定版 1.0.168**，在刷入原版固件并恢复 root SSH 后执行。通过可写文件系统补齐服务、管理 API 和“高级设置 → DOCKER”，不用制作或刷入修改版 ROM。

当前工具版本 **1.1.5**：使用内嵌 SVG 绘制 Docker 线条、CSS 绘制 64px 圆形及底部阴影，避免低分辨率 PNG 缩放和整图滤镜造成的边缘发虚。保留 70px 图标占位、文字间距和同一行的六项导航，不依赖外部图片或字体。保留 cgroup 兼容修复、磁盘绑定挂载、开机 Docker API 就绪检查和托管代理入口；代理通过[独立脚本](../docker-proxy/README.md)配置，默认关闭。

每次启动按 UUID 找到 ext4 分区后，将完整分区绑定挂载到 `/mnt/docker_disk`，供使用原厂固定路径的工具访问。当前为 `/extdisks/sda1` 时，相当于 `mount -o bind /extdisks/sda1 /mnt/docker_disk`；设备名变化仍跟随同一 UUID。目标存在文件、符号链接、其他磁盘或子目录挂载时拒绝覆盖。两个路径访问同一份数据，不复制数据，也不改写原厂热插拔脚本。卸载外接盘前应先停止 Docker，再卸载 `/mnt/docker_disk` 兼容挂载。

已在 **RA70 / 1.0.168 / Linux 4.4.60** 真机确认 Docker API 和基础容器运行。浏览器页面操作及整机重启恢复仍需验收。安装默认只准备程序和页面，使用 `--start` 或网页开关才会启动 Docker。

## 准备与安装

**1.0.168 原厂本身支持 ext4**：实际内核配置为 `CONFIG_EXT4_FS=y`、`CONFIG_JBD2=y`、`CONFIG_FS_MBCACHE=y`；原厂 `40-mount` 热插拔脚本保留识别文件系统并挂载到 `/extdisks/设备名` 的流程，默认 `anon_mount=1`。缺失的是 Docker 服务与页面，不是 ext4 驱动。此工具复用原厂挂载，只接受已成功挂载的 ext4 分区，不自动格式化，也不把“尚未挂载”当作“不支持 ext4”。

1. 刷入原版 1.0.168，恢复 root SSH。SSH 工具的前提见[统一说明](../../ssh/README.md)。脚本本身不能恢复 SSH。
2. 连接已格式化为 ext4 的 USB 盘，用 `cat /proc/mounts` 确定实际挂载点，例如 `/extdisks/sda1`。必须为可读写、允许执行的真实挂载点；也支持已有 `/mnt/docker_disk`。脚本不分区、不格式化、不挑选第一块盘，后续按 UUID 查找同一分区。新装至少需 256 MiB 可用空间，镜像/容器另需空间。
3. 将 [1.0.168 离线安装包](../../dist/1.0.168/router-docker-1.0.168-v1.1.5.tar.gz) 和 [SHA-256 校验文件](../../dist/1.0.168/router-docker-1.0.168-v1.1.5.tar.gz.sha256) 上传到 USB 盘，校验后解包；包内含已核对的原厂 Docker 下载包，不占用路由器内置存储保存大包。

```sh
cd /extdisks/sda1
sha256sum -c router-docker-1.0.168-v1.1.5.tar.gz.sha256
tar -xzf router-docker-1.0.168-v1.1.5.tar.gz
cd router-docker-1.0.168

# 核对状态，不安装
sh install-router-docker.sh status

# 将示例路径换成已确认的真实挂载点；准备程序与页面，不立即启动
sh install-router-docker.sh apply --disk /extdisks/sda1

# 或明确要求安装后启动
sh install-router-docker.sh apply --disk /extdisks/sda1 --start
```

使用源码目录时必须保留完整 `payload/` 和 `SHA256SUMS`。如果未提供同目录原厂包，脚本从小米 CDN 下载并强制校验 SHA-256；也可使用 `--archive /外接盘/docker-19.03.15-ce.tgz` 指定离线包。HTTPS 校验保持开启，不使用 `curl -k`；证书/时间异常时使用离线包。

已有旧盘时，保留原 `mi_docker/` 目录。八个程序与原厂摘要一致则复用，数据仍位于该盘 `mi_docker/lib/docker/`。程序版本不同或缺损时拒绝覆盖；脚本不会自动升级/降级引擎或删除数据。刷固件前应另外保存重要容器数据。

## 从旧版工具升级

上传并解包 1.1.5 完整离线包，在新目录运行：

```sh
sh install-router-docker.sh upgrade
```

只接受已核对的 1.0.0、1.1.0、1.1.1、1.1.2、1.1.3 或 1.1.4 运行文件，保留 Docker 开关、磁盘 UUID、Portainer 配置、原厂备份及所有容器数据。升级前运行文件留在 `/data/router-docker-1.0.168/upgrade-旧版本.*/`，升级失败尝试回退。升级不主动重启正在运行的 Docker；页面布局及图标修复刷新后生效。cgroup 兼容修复和磁盘绑定挂载在下次启动生效，如从不含这些功能的旧版升级并需立即启用，明确执行 `stop` 再执行 `start`，容器会短暂中断。

## 开机 API 就绪检查

每次开机或 procd 重试先等待指定 UUID 的 ext4 磁盘，最多 300 秒；随后启动 dockerd，并独立观察本地 Unix socket 的 `docker info`。默认 API 等待 **180 秒**，从实际匹配到本次 dockerd 后开始计时，不包含磁盘等待。

若超时，观察器同时核对 PID、进程启动时间和程序路径，只向本次实例发送 TERM，进程退出后由 procd 进行已有的有限重试；不使用强杀。进程退出或身份改变时，观察器自行退出；API 就绪后立即结束，不常驻轮询，不依赖外网或代理可用性。

可将 `mi_docker.settings.api_ready_timeout` 配置为 30–240 秒；不配置时使用 180 秒。使用单调运行时间计时，避免 NTP 校时影响。手动/页面启动沿用同一等待设置。示例：

```sh
uci set mi_docker.settings.api_ready_timeout='180'
uci commit mi_docker
logread -e router-docker168
```

## 原厂后台页面

重新登录或刷新管理后台，在“高级设置 → DOCKER”操作。原厂页面样式来自 1.0.140，适配后使用独立的 `api/routerdocker168/`，沿用后台管理员会话和 `stok` 鉴权，写操作仅接受 POST。原厂 1.0.168 的页面控制器、网络 API、功能开关、DHCP/MAC 配置保持原文件。

- “运行 Docker”开关：由 procd 启停，启动时等待指定磁盘最多 300 秒；一小时内连续失败最多尝试三次，间隔 10 秒。
- “安装 Docker”：复用已核对的程序，或重新下载并核对原厂包。
- “停用并保留数据”：关闭服务和安装标记；程序、镜像、容器、卷不删除。
- “安装第三方管理”：可选，需先通过 SSH 配置已单独验证兼容的 **ARM64 Portainer CE 镜像摘要**。不默认安装 `latest`，不使用原厂 `admin/admin`。创建的 `router-portainer168` 仅发布 LAN IPv4 的 9001 端口，首次访问创建管理员账户；已有同名容器拒绝重建。

```sh
# 先独立确认所选 Portainer 与原厂 Engine/API 1.40 的兼容性。
# 将占位符换成已核对的 64 位 SHA-256 摘要，不能原样执行。
uci set mi_docker.settings.portainer_image='portainer/portainer-ce@sha256:<已核对的ARM64镜像摘要>'
uci commit mi_docker
```

第三方管理页为可选组件，不影响 Docker CLI 或原厂开关。LAN 地址变化后需人工核对管理容器端口绑定。Docker 数据有对应容器时，按自身 restart policy 恢复；不会强行启动所有历史容器，也不删除或重建已有 Portainer。

## 状态、日志和回退

```sh
sh install-router-docker.sh status
sh install-router-docker.sh start
sh install-router-docker.sh stop
docker info
docker ps -a
logread -e dockerd
cat /tmp/router-docker168-job.log
cat /tmp/router-docker168.result

# 停止 Docker 并恢复部署前页面与配置，保留 USB 数据和备份
sh install-router-docker.sh restore
```

运行文件、原厂备份与安装记录在 `/data/router-docker-1.0.168/`，日志和操作结果在 `/tmp/`。回退前核对已部署文件和备份摘要，安装后文件被其他工具改变时拒绝覆盖。原厂已有的 `S99mi_docker` 残留链接保留，新增停止链接回退时移除。额外挂载的 cgroup 留到下次重启，避免影响其他进程；脚本不改写稳定版 `cgroup_init` 及其资源分组，不修改 `/etc/profile`，Docker API 仅监听本地 Unix socket。

OTA、出厂恢复或再次刷机后，需要重新恢复 SSH 并重新执行部署；不宣称这些操作后自动保留。回退或停用不删除外接盘数据。

## 固定组件与验证

此版使用小米包 `docker-19.03.15-ce.tgz`：CLI 19.03.15、厂商构建 dockerd `dev` / API 1.40、containerd 1.3.9、runc 1.0.0-rc10。它是恢复原厂功能的兼容基线，**不是固件支持的最高 Docker 版本**。Linux 4.4.60 缺少 seccomp 的既有限制仍然存在。组件摘要、来源及与上游版本的区别见 [SOURCES.md](SOURCES.md)。

离线验证不启动 WSL Docker，也不接触在线路由器；覆盖型号/版本/文件保护、指定磁盘、原厂摘要、重复部署、故障回退、卸载保留数据、LuCI API 鉴权注册与参数保护。已在一台 RA70 / 1.0.168 真机通过 `docker info`、本地测试容器、bridge DNS 查询与 HTTP 出网、端口映射、volume 跨容器持久化、`/mnt/docker_disk` 目录 bind mount、CPU/内存/PID 限制，以及原厂模板编译和 Docker 只读管理接口检查。镜像仓库拉取、整机重启后的磁盘恢复和原厂页面浏览器端到端操作仍未验收；不将 DNS 查询成功视为 Docker Hub 可访问。

重新打包（在仓库根目录执行，Python 3.10+）：

```sh
python3 1.0.168/docker/build-package.py --engine-archive .tools/docker168-downloads/docker-19.03.15-ce.tgz
```

[返回 1.0.168](../README.md)
